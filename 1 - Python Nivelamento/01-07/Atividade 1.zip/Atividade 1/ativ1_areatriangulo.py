base = int(input('Digite a base do retângulo: '))
altura = int(input('Digite a altura do retângulo: '))

area = (base * altura)

print('A área do retângulo é %s' %(area))