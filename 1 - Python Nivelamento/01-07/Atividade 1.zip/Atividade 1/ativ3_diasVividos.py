idade = int(input('Informe sua idade: '))

diasVividos = idade * 365

print('Você viveu %s dias' %(diasVividos))