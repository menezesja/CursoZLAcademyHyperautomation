numero = int(input('Informe um número inteiro: '))

if numero > 0:
    print('numero positivo')
elif numero < 0:
    print('numero negativo')
else:
    print('numero neutro')