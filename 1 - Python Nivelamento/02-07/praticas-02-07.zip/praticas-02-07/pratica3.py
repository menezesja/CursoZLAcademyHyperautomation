''''Escreva um programa em Python que recebe três números inteiros do usuário, que representam os
comprimentos dos lados de um triângulo. O programa deve verificar se os três lados podem formar um
triângulo. Se puderem formar um triângulo, o programa deve determinar e imprimir o tipo de triângulo: equilátero, isósceles ou escaleno.'''

a, b, c = map(int, (input('Informe 3 numeros inteiros, separado por um espaço: ').split()))

if (a + b < c) or (a + c < b) or (b + c < a):
    print('Não é um triangulo')
elif (a == b) and (a ==c ) and (b==c):
    print('triângulo equilatero')
elif (a == b) and (a != c ) and (b != c):
    print('triângulo isósceles')
else:
    print('triângulo escaleno')